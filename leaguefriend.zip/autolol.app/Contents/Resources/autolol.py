# -*- coding: utf-8 -*-
# @Author: caspar
# @Date:   2018-08-02 10:22:39
# @Last Modified by:   caspar
# @Last Modified time: 2018-08-03 22:47:27

import rumps
import urllib
from monitor import LeagueMonitor
import subprocess
import os
import threading 
import time




class LeagueFriend(rumps.App):

    @rumps.clicked("Preferences")
    def prefs(self, _):
        rumps.alert("Not implemented yet.")

    def autocheck(self):
        m = LeagueMonitor()
        sleep_time = 1
        previous = None
        while self._AUTOMODE_:
            state = m.getClientState()
            if state in ["Matchmaking", "ReadyCheck"]:
                sleep_time = 6
            elif state == "InProgress":
                sleep_time = 60
            elif state == "ChampSelect" and state != previous:
                url = 'https://porofessor.gg/pregame/euw/'
                for player in m.getTeammembers()['myTeam']:
                    url = url + "{},".format(urllib.parse.quote(m.getPlayerNameByID(int(player['summonerId']))))
                subprocess.call(["open", "-W", "-n", "-a", os.path.realpath("./resources/browser.app"), "--args", url])
                sleep_time = 10
            else:
                sleep_time = 30

            time.sleep(sleep_time)
            previous = state

    @rumps.clicked("Check Stats")
    def check_stats(self, _):
        m = LeagueMonitor()
        if m.getClientState() == "ChampSelect":
            url = 'https://porofessor.gg/pregame/euw/'
            for player in m.getTeammembers()['myTeam']:
                url = url + "{},".format(urllib.parse.quote(m.getPlayerNameByID(int(player['summonerId']))))
            subprocess.call(["open", "-W", "-n", "-a", os.path.realpath("./resources/browser.app"), "--args", url])
        else:
            rumps.alert("Can't find running League of Legends client, or not in champion selection.")
    
    @rumps.clicked("Automatic Mode")
    def auto_mode(self, sender):
        sender.state = not sender.state
        if sender.state:
            self._AUTOMODE_ = True
            self.child_process = threading.Thread(target=self.autocheck)
            self.child_process.start()
        else:
            self._AUTOMODE_ = False


def main():
    LeagueFriend("League Friend", icon=os.path.realpath("resources/app.icns")).run()

main()