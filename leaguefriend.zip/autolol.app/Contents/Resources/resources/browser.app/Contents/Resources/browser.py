# -*- coding: utf-8 -*-
# @Author: caspar
# @Date:   2018-08-02 10:22:39
# @Last Modified by:   caspar
# @Last Modified time: 2018-08-03 15:59:08

import toga
from toga.style.pack import *

browser = None

class Browser(toga.App):

    def setURL(self, url):
        self.url = url

    def startup(self):
        self.main_window = toga.MainWindow(title=self.name, size=(1280,800))

        self.webview = toga.WebView(style=Pack(flex=1))

        box = toga.Box(
            children=[
                self.webview,
            ],
            style=Pack(
                direction=COLUMN
            )
        )

        self.main_window.content = box
        self.webview.url = self.url

        # Show the main window
        self.main_window.show()


def open_url(url):
    global browser
    if not browser:
        browser = Browser('League Friend', 'org.leaguefriend', icon="resources/app.icns")
        browser.setURL(url)
        browser.main_loop()
    else:
        browser.setURL(url)
        browser.main_window.show()

import sys
open_url(sys.argv[1])